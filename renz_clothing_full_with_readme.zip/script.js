
document.addEventListener("DOMContentLoaded", () => {
  const cart = JSON.parse(localStorage.getItem("cart")) || [];

  // Add to cart buttons
  document.querySelectorAll(".add-cart").forEach(btn => {
    btn.addEventListener("click", () => {
      const name = btn.dataset.name;
      const price = btn.dataset.price;
      cart.push({ name, price });
      localStorage.setItem("cart", JSON.stringify(cart));
      alert(name + " ditambahkan ke keranjang!");
    });
  });

  // Checkout redirect
  const cartBtn = document.getElementById("cart-btn");
  if (cartBtn) {
    cartBtn.addEventListener("click", () => {
      window.location.href = "keranjang.html";
    });
  }
});
