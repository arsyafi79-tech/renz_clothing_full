# 🛍️ Renz Clothing E-Commerce

Website e-commerce sederhana untuk **Renz Clothing**, dibuat dengan
HTML, CSS, dan JavaScript.\
Website ini mendukung fitur login, registrasi, kategori produk,
keranjang belanja, pembayaran online, ulasan produk, filter, pencarian,
dan rekomendasi produk.

------------------------------------------------------------------------

## 🚀 Fitur Utama

-   Login & Registrasi Akun
-   Halaman utama dengan produk populer
-   Kategori Produk (Baju, Celana, Sepatu)
-   Detail Produk + Ulasan & Rekomendasi
-   Keranjang Belanja + Checkout
-   Pembayaran via **Dana, OVO, Gojek**
-   Pencarian Produk berdasarkan kata kunci
-   Filter Produk (kategori, harga, warna, ukuran)
-   Notifikasi Promo & Produk Baru (dummy)
-   Responsive (Mobile & Desktop)

------------------------------------------------------------------------

## 📂 Struktur Project

    renz_clothing/
    │── index.html        # Halaman utama
    │── login.html        # Login
    │── register.html     # Registrasi
    │── kategori/
    │     ├── baju.html   # Produk baju (Kaos, Kemeja)
    │     ├── celana.html # Produk celana (Panjang, Jeans)
    │     └── sepatu.html # Produk sepatu (Formal, Sneakers)
    │── produk.html       # Detail produk (ulasan & rekomendasi)
    │── keranjang.html    # Keranjang belanja
    │── checkout.html     # Pembayaran (Dana, OVO, Gojek)
    │── style.css         # CSS global
    │── script.js         # JavaScript global
    │── assets/           # Gambar produk + logo pembayaran + logo toko

------------------------------------------------------------------------

## 🖥️ Cara Menjalankan di Lokal

1.  Download dan ekstrak file `renz_clothing_full.zip`
2.  Buka folder `renz_clothing/`
3.  Klik **index.html** untuk membuka website di browser

------------------------------------------------------------------------

## 🌐 Hosting di GitHub Pages

1.  Buat repository baru di GitHub (contoh: `renz-clothing`)

2.  Upload semua file dari folder `renz_clothing/`

3.  Masuk ke **Settings \> Pages**

4.  Pilih **Branch: main** dan folder `/root`

5.  Website bisa diakses di URL:

        https://USERNAME.github.io/renz-clothing/

------------------------------------------------------------------------

## 📱 Desain

-   Tema warna: **Biru/Ungu gradasi (petir aesthetic)**
-   Font: Modern dan mudah dibaca
-   Gambar produk: Placeholder berkualitas tinggi

------------------------------------------------------------------------

👕👟 Dibuat untuk keperluan demo toko online **Renz Clothing**.
